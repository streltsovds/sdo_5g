//Script block used to bypass ActiveX Controls Activation on IE6 (KB912945)
objects = document.getElementsByTagName("object");
for (var i = 0; i < objects.length; i++)
{
    objects[i].outerHTML = objects[i].outerHTML;
}
