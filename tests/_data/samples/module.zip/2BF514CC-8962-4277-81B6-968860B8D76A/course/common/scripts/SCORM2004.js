﻿var API_OBJ_NAME = 'API_1484_11';

// names of SCORM methods

var INITIALIZE = 'Initialize';
var TERMINATE = 'Terminate';
var GET_VALUE = 'GetValue';
var SET_VALUE = 'SetValue';
var COMMIT = 'Commit';
var GET_LAST_ERROR = 'GetLastError';
var GET_ERROR_STRING = 'GetErrorString';
var GET_DIAGNOSTIC = 'GetDiagnostic';

var SESSION_TIME = "cmi.session_time";

function converTime(time_ms)
{
	var hms = "PT"; 
	var dtm = new Date();
	dtm.setTime(time_ms);
	var h = Math.floor(time_ms / 3600000); 
	hms += (h > 0) ? h + "H" : "";

	var m = dtm.getMinutes(); 
	hms += (m > 0) ? m + "M" : "";

	var cs = Math.round(dtm.getMilliseconds() / 10); 
	hms += dtm.getSeconds() + "." + fitNumByZeros(cs, 2) + "S";	
	
	return hms;
}



