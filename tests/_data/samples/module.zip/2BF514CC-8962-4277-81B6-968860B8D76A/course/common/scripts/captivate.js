function onEnd(target)
{
	getCourse("course").onEnd(target);
}
function setInputFieldActive(b)
{
	getCourse("course").setInputFieldActive(b);
}
function setAnswer(target, mark, totalMark)
{
	getCourse("course").setAnswer(target, mark, totalMark);
}
function getCourse() 
{
    if (navigator.appName.indexOf("Microsoft") != -1) 
        return window["course"];    
    else 
        return document["course"];
}