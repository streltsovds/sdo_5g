/**
	For saving changes from EDIT MODE
**/
var FILE_NAME = "business_game_edit.xml";

var location = document.location.href;	
location = location.split("file:").join("");
location = location.split("///").join("");

var arr = location.split("/");
var url = "";
for (var i=0; i<arr.length-1; i++)
	url += arr[i]+"/";
url = unescape(url + FILE_NAME);

var fso;
var ForWriting = 2;

function writeToFile(text)
{		
	if (fso == undefined)
	{
		fso = new ActiveXObject("Scripting.FileSystemObject");
		fso.CreateTextFile(url);		
		alert("Запись в файл " + url);
	}	
	var file = fso.GetFile(url);		
	var ts = file.OpenAsTextStream(ForWriting, true);
	ts.Write(text); 	
	ts.Close(); 
}