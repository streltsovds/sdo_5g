﻿var search = document.location.search.substring(1);

if (search != "")
{
	var aicc_url;
	var aicc_sid;

	var arr = search.split("&");
	var arr1;
	for (var i = 0; i < arr.length; i++)
	{
		arr1 = arr[i].split("=");
		if (arr1[0].toLowerCase() == "aicc_url")
			aicc_url = arr1[1];
		else if (arr1[0].toLowerCase() == "aicc_sid")	
			aicc_sid = arr1[1];
	}
}

if (aicc_url != undefined && aicc_sid != undefined)
{
	trackingTerminated = 0;
	
	document.write("<form action=\'" + unescape(aicc_url) + "\' method=\'POST\' name=\'exitform\' id=\'exitform\'>");
	document.write("<input type=\'hidden\' name=\'command\' value=\'ExitAU\'>");
	document.write("<input type=\'hidden\' name=\'session_id\' value=\'" + unescape(aicc_sid) + "\'>");
	document.write("<input type=\'hidden\' name=\'version\' value=\'2.0\'>");
	document.write("</form>");
	
	window.setTrackingState = function (n)
	{
		trackingTerminated = n;
	}
	
	window.closeSession = function ()
	{
		if (trackingTerminated == 0)
		{
			var winWidth = 550;
			var winHeight = 50;
			var winLeftPos = (screen.width - winWidth)/2;
			var winTopPos = (screen.height - winHeight)/2;
			var tempWindow = window.open("../common/unload.html","_blank","channelmode=no,directories=no,fullscreen=no,location=no,menubar=no,resizable=no,scrollbars=no,status=no,titlebar=no,toolbar=no,width=" + winWidth + ",height=" + winHeight + ",left=" + winLeftPos + ",top=" + winTopPos);

			exitform.submit();
			
			tempWindow.close();
		}
		
		// confirm ("Вы действительно хотите выйти из курса?");
	}
	
	if (navigator.appName.indexOf("Internet Explorer") != -1) // IE
		window.onunload = window.closeSession;
	else
		window.onbeforeunload = window.closeSession;

}
