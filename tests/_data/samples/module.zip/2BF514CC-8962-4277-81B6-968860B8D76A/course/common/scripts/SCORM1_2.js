﻿var API_OBJ_NAME = 'API';

// names of SCORM methods

var INITIALIZE = 'LMSInitialize';
var TERMINATE = 'LMSFinish';
var GET_VALUE = 'LMSGetValue';
var SET_VALUE = 'LMSSetValue';
var COMMIT = 'LMSCommit';
var GET_LAST_ERROR = 'LMSGetLastError';
var GET_ERROR_STRING = 'LMSGetErrorString';
var GET_DIAGNOSTIC = 'LMSGetDiagnostic';

var SESSION_TIME = "cmi.core.session_time";


function converTime(time_ms)
{
	var hms = "";
	var dtm = new Date();
	dtm.setTime(time_ms); 
	var h = Math.floor(time_ms / 3600000); 
	hms += fitNumByZeros(h, 2) + ":";
	//hms += (h > 0) ? h + ":" : "";

	var m = dtm.getMinutes(); 
	hms += fitNumByZeros(m, 2) + ":";
	//hms += (m > 0) ? m + ":" : "";

	var cs = Math.round(dtm.getMilliseconds() / 10); 
	hms += fitNumByZeros(dtm.getSeconds(), 2) + "." + fitNumByZeros(cs, 2);
	
	return hms;
}

