﻿/**
	method - close window.
**/
function closeWin(){
	var win = window;
	var findParentTries = 0;
   	while ((win.parent != null) &&
           (win.parent != win)){
		findParentTries++;

      	if ( findParentTries > 500 ){
	         alert( "Error close Window -- too deeply nested." );
	         return null;
      	}
      	win = win.parent;
   	}
   	win.close();
}
/**
	method - load XML to xmlDoc variable.
**/
//only for IE
var xmldoc = new ActiveXObject("Microsoft.XMLDOM");
var xmldocLoaded = false;
var stylesheet = new ActiveXObject("Microsoft.XMLDOM");
var xsldocLoaded = false;
function loadElementXML(xmlUrl, stylesheeUrl){
	if(window.ActiveXObject){
		xmldoc.onreadystatechange = onXMLLoaded; 
		stylesheet.onreadystatechange = onXSLLoaded;
		xmldoc.preserveWhiteSpace = true;
		xmldoc.load(xmlUrl);
		stylesheet.load(stylesheeUrl);
	}else{
		alert('ActiveXObject not supported, printing isn\'t available');
	}
}
/**
	method - callback when loaded Element XML.
**/
function onXMLLoaded(){
	//alert('xmldoc.parseError.errorCode : '+xmldoc.parseError.errorCode); 
	xmldocLoaded = xmldoc.parseError.errorCode == 0;
}
function onXSLLoaded(){
	//alert('stylesheet.parseError.errorCode : '+stylesheet.parseError.errorCode); 
	xsldocLoaded = stylesheet.parseError.errorCode == 0;
}

/**
	method - finds lesson slide by index, applyes xsl transformation to it and calls showPopUp.
**/
function printLessonSlide(i){
	if(xmldocLoaded){
		//alert('printLessonSlide : '+i);
		var item = xmldoc.firstChild.selectNodes('//slide').item(i);
		//alert('item = '+item.xml);
		item = preprocessHTML(item);
		showPopUp(item);
	}
}
/**
	method - finds test slide by nodeName, applyes xsl transformation to it and calls showPopUp.
**/
function printTestSlide(nodeName){
	if(xmldocLoaded){
		alert('printTestSlide : '+nodeName);
		var item = xmldoc.selectSingleNode('//'+nodeName);
		item = preprocessHTML(item);
		showPopUp(item);
	}
}
/**
	method - returns valid html to write into document
**/
function preprocessHTML(node){
	if(node == null){ 
		return null;
	}

	//TODO remove attribute xmlns to prevent crash of xsl preprocessor 
	var html = node.selectSingleNode('//html');
	if(html!= null){
		//alert('0. xmlns = '+html.xml);
		
		//Don't work!
		html.removeAttribute('xmlns');
		
		//Don't work too!
		html.parentNode.replaceChild(html.firstChild, html);
		
		//TODO Find way to remove attribute @xmlns
		//alert('1. xmlns = '+html.xml);
	}
	
	//alert('1. xmlns = '+node.selectSingleNode('//html').xml);
	if(xsldocLoaded){
		var res = node.transformNode(stylesheet);
		return res;
	}
	//if(html != null)
	//	node = html.selectSingleNode('//body');
	return node.xml;
}

/**
	method - open popup with xmlnode.
**/
function showPopUp(node){
	if(node == null){ 
		alert('{showPopUp} [Parse error] popUp node is null!');
		return null;
	}
	
	var popup = window.open("", "messageWindow", "scrollbars=yes,status=no,width=600,height=500");	
	
	popup.document.open();
	popup.document.write('<TITLE>Print preview</TITLE>');
	popup.document.write('<META http-equiv="Content-Type" content="text/html; charset=UTF-8" />');
	popup.document.write(node);
	popup.document.write('<center><a href="javascript: if (typeof(window.print) != \'undefined\') {window.print();}">Print</a>');
	popup.document.write('&nbsp;&nbsp;<a href="javascript: close();">Close</a></center>');
	popup.document.close();
}
/**
	method - open window.
**/
function windowOpen(url, name, param)
{
	if (name == undefined)
		name = "";
	if (param == undefined)
		param = "";	
	window.open(url, name, param)
}


/**
	Для вызова через ExternalInterface
**/
function onEnd(url)
{
	getSWF("course").onEnd(url);
}
function setInputFieldActive(b)
{
	getSWF("course").setInputFieldActive(b);
}
function setAnswer(a, b)
{
	getSWF("course").setAnswer(a, b);
}

function getSWF(id) 
{
    if (navigator.appName.indexOf("Microsoft") != -1) 
        return window[id];    
    else 
        return document[id];
}
	var count=0;
	function print_course(strxml) {

		if (window.ActiveXObject) { 
			var printXML=new ActiveXObject("Msxml2.DOMDocument");
			printXML.async="false";
			printXML.loadXML (strxml);
			var printXSL=new ActiveXObject("Msxml2.DOMDocument");
		} else {
			parser=new DOMParser();
	    printXML=parser.parseFromString(strxml,"text/xml");
	    printXSL=document.implementation.createDocument("","",null);
		}
   	printXSL.async=false;
 		printXSL.load("../common/slide.xsl");
		if (window.ActiveXObject) {
			var resultHTML = printXML.transformNode(printXSL);
		} else {
			var processor = new XSLTProcessor();
		  processor.importStylesheet(printXSL);
  		var resultHTML = processor.transformToDocument(printXML);
		}
		printWnd = open("","myWin"+count,"");
		printWnd.document.write(resultHTML);
		count++;
	}